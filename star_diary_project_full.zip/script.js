const canvas = document.getElementById("starfield");
const ctx = canvas.getContext("2d");
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

let stars = [];
for (let i = 0; i < 300; i++) {
  stars.push({
    x: Math.random() * canvas.width,
    y: Math.random() * canvas.height,
    radius: Math.random() * 1.5,
    alpha: Math.random(),
    speed: Math.random() * 0.02
  });
}

function drawStars() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  stars.forEach(star => {
    ctx.beginPath();
    ctx.arc(star.x, star.y, star.radius, 0, Math.PI * 2);
    ctx.fillStyle = `rgba(255, 255, 255, ${star.alpha})`;
    ctx.fill();
    star.alpha += star.speed;
    if (star.alpha <= 0 || star.alpha >= 1) star.speed *= -1;
  });
  requestAnimationFrame(drawStars);
}

document.getElementById("enter-btn").addEventListener("click", () => {
  document.getElementById("enter-screen").style.display = "none";
  canvas.style.display = "block";
  document.getElementById("sfx-whoosh").play();
  drawStars();
});

// Simple constellation (Orion example)
const constellations = [
  {
    name: "Orion",
    description: "Orion, the hunter, a prominent constellation with rich mythology.",
    stars: [{x:200,y:200},{x:250,y:250},{x:300,y:200},{x:350,y:250}]
  }
];

canvas.addEventListener("click", (e) => {
  const { offsetX, offsetY } = e;
  constellations.forEach(cons => {
    cons.stars.forEach(star => {
      let dx = star.x - offsetX;
      let dy = star.y - offsetY;
      if (Math.sqrt(dx*dx+dy*dy) < 20) {
        document.getElementById("constellation-name").innerText = cons.name;
        document.getElementById("constellation-description").innerText = cons.description;
        document.getElementById("lore-book").classList.remove("hidden");
        document.getElementById("sfx-chime").play();
      }
    });
  });
});

document.getElementById("close-book").addEventListener("click", () => {
  document.getElementById("lore-book").classList.add("hidden");
});

// Diary save & export
document.getElementById("save-diary").addEventListener("click", () => {
  localStorage.setItem("diary", document.getElementById("diary-text").value);
  alert("Diary saved!");
});

document.getElementById("export-diary").addEventListener("click", () => {
  const text = document.getElementById("diary-text").value;
  const blob = new Blob([text], { type: "text/plain" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "diary.txt";
  a.click();
});